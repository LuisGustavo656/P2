<?php
session_start();
include 'includes/db.php';
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit();
}
$usuario_id = $_SESSION['usuario_id'];
$sql = "SELECT email, senha FROM usuarios WHERE id = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    $usuario = $result->fetch_assoc();
    $email = $usuario['email'];
} else {
    echo "Usuário não encontrado!";
    exit();
}
$erro = "";
$sucesso = "";
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $senha_atual_informada = $_POST['senha_atual'];
    $nova_senha = $_POST['nova_senha'];
    $confirmacao_nova_senha = $_POST['confirmacao_nova_senha'];

    try {
        $sql = "SELECT senha FROM usuarios WHERE email = ?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("s", $email);
        $stmt->execute();
        $result = $stmt->get_result();
        
        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            $senha_atual_hash = $user['senha'];
            if (!password_verify($senha_atual_informada, $senha_atual_hash)) {
                $erro = "Senha atual informada está incorreta.";
            } elseif ($nova_senha !== $confirmacao_nova_senha) {
                $erro = "A nova senha e a confirmação não coincidem.";
            } else {
                $nova_senha_hash = password_hash($nova_senha, PASSWORD_DEFAULT);
                $sql = "UPDATE usuarios SET senha = ? WHERE email = ?";
                $stmt = $conn->prepare($sql);
                $stmt->bind_param("ss", $nova_senha_hash, $email);
                $stmt->execute();

                $sucesso = "Senha atualizada com sucesso!";
            }
        } else {
            $erro = "Usuário não encontrado!";
        }
    } catch (PDOException $e) {
        $erro = "Erro ao consultar o banco de dados: " . $e->getMessage();
    }
}

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Redefinir Senha</title>
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f8f9fa;
            margin: 0;
            padding: 0;
        }
        .header {
            text-align: center;
            padding: 20px;
            font-size: 24px;
            font-weight: bold;
            background-color: #ffffff;
            box-shadow: 0px 2px 4px rgba(0, 0, 0, 0.1);
        }
        .container {
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            max-width: 600px;
            margin: 20px auto;
            padding: 20px;
            background-color: #ffffff;
            border-radius: 10px;
            box-shadow: 0px 0px 15px rgba(0, 0, 0, 0.2);
        }
        .container h2 {
            margin-bottom: 20px;
            color: #007bff;
            display: flex;
            align-items: center;
            justify-content: center;
        }
        .container h2 img {
            margin-right: 10px;
            width: 54px;
            height: 50px; 
            border-radius: 50%;
        }
        .container form {
            width: 100%;
            max-width: 500px;
            display: flex;
            flex-direction: column;
            align-items: center;
        }
        .container label {
            display: block;
            margin-bottom: 10px;
            color: #495057;
        }
        .container input[type="password"] {
            width: 100%;
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ced4da;
            border-radius: 5px;
        }
        .container .button-wrapper {
            display: flex;
            flex-direction: column;
            align-items: center;
            width: 100%;
        }
        .container button {
            background-color: #007bff;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
            width: 100%;
            max-width: 200px;
            margin-bottom: 10px;
        }
        .container button:hover {
            background-color: #0056b3;
        }
        .error {
            color: #dc3545;
            margin-bottom: 20px;
        }
        .success {
            color: #28a745;
            margin-bottom: 20px;
        }
        .button-group {
            display: flex;
            justify-content: flex-end;
            width: 100%;
        }
        .button-group a {
            background-color: #6c757d;
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-size: 16px;
            transition: background-color 0.3s ease;
        }
        .button-group a:hover {
            background-color: #5a6268;
        }
    </style>
</head>
<body>

    <div class="header">
        Redefinir Senha
    </div>

    <div class="container">
        <h2><img src="https://cdn-icons-png.flaticon.com/512/6195/6195699.png" alt="Ícone"> Alterar Senha</h2>

        <?php if ($erro): ?>
            <div class="error"><?php echo htmlspecialchars($erro); ?></div>
        <?php endif; ?>

        <?php if ($sucesso): ?>
            <div class="success"><?php echo htmlspecialchars($sucesso); ?></div>
        <?php endif; ?>

        <form method="POST" action="">
            <label for="senha_atual">Senha Atual</label>
            <input type="password" id="senha_atual" name="senha_atual" required>

            <label for="nova_senha">Nova Senha</label>
            <input type="password" id="nova_senha" name="nova_senha" required>

            <label for="confirmacao_nova_senha">Confirme Nova Senha</label>
            <input type="password" id="confirmacao_nova_senha" name="confirmacao_nova_senha" required>

            <div class="button-wrapper">
                <button type="submit">Atualizar Senha</button>
                <div class="button-group">
                    <a href="conta.php">Voltar</a>
                </div>
            </div>
        </form>
    </div>

</body>
</html>
