<?php
include 'includes/db.php';
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add_to_cart'])) {
    $produto_id = $_POST['produto_id'];
    $usuario_id = 1;
    $quantidade = 1;
    $tamanho = $_POST['tamanho'];

    $sql = "SELECT * FROM carrinho WHERE usuario_id = $usuario_id AND produto_id = $produto_id";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        $conn->query("UPDATE carrinho SET quantidade = quantidade + 1 WHERE usuario_id = $usuario_id AND produto_id = $produto_id");
    } else {
        $conn->query("INSERT INTO carrinho (usuario_id, produto_id, quantidade, tamanho) VALUES ($usuario_id, $produto_id, $quantidade, '$tamanho')");
    }

    header('Location: carrinho.php');
}

$sql = "SELECT c.*, p.nome, p.preco, p.imagem FROM carrinho c JOIN produtos p ON c.produto_id = p.id WHERE c.usuario_id = 1";
$result = $conn->query($sql);
?>
<?php
if (isset($_POST['delete_all'])) {
    $usuario_id = 1;
    $sql = "DELETE FROM carrinho WHERE usuario_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $usuario_id);

    if ($stmt->execute()) {
        echo "Todos os itens foram removidos do carrinho!";
        header("Location: carrinho.php");
        exit;
    } else {
        echo "Erro ao remover itens: " . $conn->error;
    }
}


if (isset($_POST['delete_one'])) {
    $usuario_id = 1;
    $produto_id = $_POST['produto_id'];

    $sql = "SELECT quantidade FROM carrinho WHERE usuario_id = ? AND produto_id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ii", $usuario_id, $produto_id);
    $stmt->execute();
    $result = $stmt->get_result();
    $item = $result->fetch_assoc();

    if ($item['quantidade'] > 1) {
        $conn->query("UPDATE carrinho SET quantidade = quantidade - 1 WHERE usuario_id = $usuario_id AND produto_id = $produto_id");
    } else {
        $conn->query("DELETE FROM carrinho WHERE usuario_id = $usuario_id AND produto_id = $produto_id");
    }

    header("Location: carrinho.php");
    exit;
}

$conn->close();
?>
<?php include 'includes/header.php'; ?>
<head>
    <link rel="stylesheet" href="style.css">
    
</head>
<h1>Seu Carrinho</h1>
<div class="carrinho">
    <?php while ($item = $result->fetch_assoc()) : ?>
        <div class="item d-flex align-items-center mb-4">
            <img src="uploads/<?php echo $item['imagem']; ?>" alt="<?php echo $item['nome']; ?>" class="img-thumbnail" style="width: 250px; height: 250px;">

            <div class="ms-3">
                <h2><?php echo $item['nome']; ?></h2>
                <p>Preço: R$ <?php echo number_format($item['preco'], 2, ',', '.'); ?></p>
                <p>Quantidade: <?php echo $item['quantidade']; ?></p>
                <p>Tamanho: <?php echo $item['tamanho']; ?></p>

                <form method="POST" style="display:contents;">
                    <input type="hidden" name="produto_id" value="<?php echo $item['produto_id']; ?>">
                    <button type="submit" name="delete_one" class="btn btn-warning btn-sm">Excluir 1</button>
                </form>
            </div>
        </div>
    <?php endwhile; ?>
</div>

<div class="carrinho-botoes">
    <form method="POST" style="display:contents;">
        <button type="submit" name="delete_all" class="btn btn-danger">Excluir Todos os Itens</button>
        <a href="checkout.php" class="btn btn-success">Finalizar Compra</a>
    </form>
</div>
<br></br>

<footer>
    <p>&copy; 2024 Loja de Roupas. Todos os direitos reservados.</p>
</footer>
